package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BasePage {
	
	WebDriver driver;
	public BasePage(WebDriver driver){
		this.driver=driver;
	}
	
	By AllProducts 	 = By.id("findAll");
	By InStock       = By.id("findAllProductsInStock");
	By OutOfStock    = By.id("findAllProductsOutOfStock");
	By SearchProduct = By.id("productId");
	By Search        = By.id("searchProduct");
	
	public WebElement FindAllProducts()
	{
		return driver.findElement(AllProducts);
	}
	
	public WebElement ProductsInStock()
	{
		return driver.findElement(InStock);
	}
	
	public WebElement ProductsOutOfStock()
	{
		return driver.findElement(OutOfStock);
	}
	
	public WebElement SearchBar()
	{
		return driver.findElement(SearchProduct);
	}
	
	public WebElement SearchTab()
	{
		return driver.findElement(Search);
	}
}
