package stepdefinitions;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyRetail {
	
	static WebDriver driver;
	private static final Logger LOG = Logger.getLogger(MyRetail.class);

	@Given("^Product details page is launched$")
	public void product_details_page_is_launched() throws Throwable {
		driver = new FirefoxDriver();
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("C:\\Automation\\workspace\\MyRetailAutomation\\src\\test\\resources\\parameters.properties");
		prop.load(fis);
	    driver.get(prop.getProperty("targeturl"));
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS); 
	}

	@When("^User clicks on Find All Products$")
	public void user_clicks_on_Find_All_Products() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.FindAllProducts().click();
	}

	@Then("^All Product details should be displayed$")
	public void all_Product_details_should_be_displayed() throws Throwable {
	    List<WebElement>rows = get_rows();
	    int actualRowSize =rows.size();
	    int expectedRowSize = 6;
	    if(actualRowSize==expectedRowSize)
	    {
	    	LOG.info("All Product details are displayed");
	    }else {
	    	LOG.info("Actual Row size is " +actualRowSize);
	    	LOG.info("All Product details are not displayed");
	    	Assert.assertFalse("Missing product details",true);
	    }
	}

	@Given("^User clicks on Find All Products in stock$")
	public void user_clicks_on_Find_All_Products_in_stock() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.ProductsInStock().click();
	}

	@Then("^All Product details in stock should be displayed$")
	public void all_Product_details_in_stock_should_be_displayed() throws Throwable {
	    List<WebElement>rows = get_rows(); 
	    int qty = 0;
	    String colVal = null;
	    int i=0;
	    for(WebElement eachrow:rows)
	    {
	      List<WebElement>column = eachrow.findElements(By.tagName("td"));
	      i++;
	      if(i>1){
	    	  		for(WebElement text:column)
	    	  			{
	    	  				colVal = text.getText();
	    	  			}
	      if (!colVal.equals(""))
	    	  qty = Integer.parseInt(colVal);
	      	  if (qty != 0){
	      		  	LOG.info("Items are in stock");
	      		  		   }
	      	  else	{
	      		LOG.info("Error: Some items are out of stock");
	      		LOG.info("Quantity is" +qty);
	      		Assert.assertFalse("Items out of stock",true);
	      		 	}
	      		 }
	    }
	 }


	@Given("^User clicks on Find All Products out of stock$")
	public void user_clicks_on_Find_All_Products_out_of_stock() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.ProductsOutOfStock().click();
	}

	@Then("^All Product details out of stock should be displayed$")
	public void all_Product_details_out_of_stock_should_be_displayed() throws Throwable {
	    List<WebElement>rows = get_rows();
	    int qty = 0;
	    String colVal = null;
	    int i=0;
	    for(WebElement eachrow:rows)
	    {
	      List<WebElement>column = eachrow.findElements(By.tagName("td"));
	      i++;
	      if(i>1){
	    	  		for(WebElement text:column)
	    	  			{
	    	  				colVal = text.getText();
	    	  			}
	      if (!colVal.equals(""))
	    	  qty = Integer.parseInt(colVal);
	      	  System.out.println(+qty);
	      	if (qty == 0){
		    	  LOG.info("Items are out of stock");
		      			 }
		      else {
		    	  LOG.info("Error: Some items are in stock");
		    	  LOG.info("Quantity is" +qty);
		    	  Assert.assertFalse("Items in stock",true);
		      	   }
	      		 }
	    }
	    
	}

	@Given("^User enters valid product id for Milk in search bar$")
	public void user_enters_valid_product_id_for_Milk_in_search_bar() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.SearchBar().sendKeys("010001"); 
	}

	@Given("^Clicks on search$")
	public void clicks_on_search() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.SearchTab().click();  
		
	}

	@Then("^Product details of Milk should be displayed$")
	public void product_details_of_Milk_should_be_displayed() throws Throwable {
	    List<WebElement>rows = get_rows();
	    String colVal = null;
	    String expectedVal = "Milk";
	    for(WebElement eachrow:rows)
	    	{
	    		List<WebElement>column = eachrow.findElements(By.tagName("td"));
	    		int col=0;
	    		for(WebElement text:column)
	    	  		{
	    			  col++;
	    	  		  colVal = text.getText();
	    	  		  if (col == 2 ){
	    	  			  LOG.info(colVal);
	    	  			  Assert.assertTrue(colVal.equals(expectedVal));
	    	  		  				}
	    	  		}
	    	  		    
	    	}
	    
	}

	@Given("^User enters invalid product id in search bar$")
	public void user_enters_invalid_product_id_in_search_bar() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.SearchBar().clear();
		obj.SearchBar().sendKeys("invalid-id");
		obj.SearchTab().click();
	    
	}

	@Then("^No rows should be displayed$")
	public void no_rows_should_be_displayed() throws Throwable {
	    List<WebElement>rows = get_rows();
	    int rowsize = rows.size();
	    if(rowsize==1){
	    	LOG.info("No Rows displayed");
	    			  }
	    else{
	    	LOG.info("Rows does not match");
	    	Assert.assertFalse("Invalid row size",true);
	    	
	    }
	}

	@Given("^User does not enter any data in search bar$")
	public void user_does_not_enter_any_data_in_search_bar() throws Throwable {
		BasePage obj = new BasePage(driver);
		obj.SearchBar().clear();
		obj.SearchBar().sendKeys("");
	}

	@Then("^Valid Error message should be thrown to the user$")
	public void valid_Error_message_should_be_thrown_to_the_user() throws Throwable {
		 String Errormsg = driver.findElement(By.id("error-msg")).getText();
		 String ExpectedErrormsg = "No product id entered to search!!!";
		 Assert.assertTrue(Errormsg.equals(ExpectedErrormsg));
		 driver.quit();
	}
	
	public List<WebElement> get_rows(){
	WebElement table = driver.findElement(By.id("productTable"));
    List<WebElement>rows = table.findElements(By.tagName("tr"));
    return rows;
	}
	
}
	

