package runners;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;

@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(
jsonReport = "target/cucumber.json",
jsonUsageReport = "target/cucumber-usage.json",
outputFolder = "target",
detailedReport = true,
detailedAggregatedReport = true,
overviewReport = true,
usageReport = true,
coverageReport = false,
retryCount=0,
toPDF = true
)
@CucumberOptions(
plugin = {"html:target/cucumber-html-report",
"json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
"usage:target/cucumber-usage.json",
"junit:target/cucumber-results.xml"
},
features = {"src/test/java/featurefile"},
glue = {"stepdefinitions"}
)

public class MyRetailTest {

}
