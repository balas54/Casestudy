package performance;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;


public class AppLaunch {
	
	@Test
	public void startup() {
		WebDriver driver = new HtmlUnitDriver();
		driver.get("http://localhost:8080/myRetail/");
		String expectedTitle = "myRetail";
		String actualTitle = driver.getTitle();
		Assert.assertTrue(expectedTitle.equals(actualTitle));
	}
}



