package performance;

import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

	public class Search {

		@Test
		public void start() {
			
			WebDriver driver = new HtmlUnitDriver();
			driver.get("http://localhost:8080/myRetail/");
			WebElement searchbar = driver.findElement(By.id("productId"));
			searchbar.sendKeys("010001");
			WebElement searchtab = driver.findElement(By.id("searchProduct"));
			searchtab.click();
			WebElement table = driver.findElement(By.id("productTable"));
		    List<WebElement>rows = table.findElements(By.tagName("tr"));
		    String colVal = null;
		    String expectedVal = "Milk";
		    for(WebElement eachrow:rows)
		    	{
		    		List<WebElement>column = eachrow.findElements(By.tagName("td"));
		    		int col=0;
		    		for(WebElement text:column)
		    	  		{
		    			  col++;
		    	  		  colVal = text.getText();
		    	  		  if (col == 2 ){
		    	  			  System.out.println(colVal);
		    	  			  Assert.assertTrue(colVal.equals(expectedVal));
		    	  		  				}
		    	  		}
		    	  		    
		    	}
		 
		}



}


